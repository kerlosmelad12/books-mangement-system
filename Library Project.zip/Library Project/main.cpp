#include<iostream>
#include<string>
#include<fstream>
#include<vector>
#include"lib.h"

using namespace std;

int main() {
    Book_Management bookManager;
    customer_Management customerManager;
    Transaction_Management transactionManager;

    int choice;
    cout << "Welcome to the Library Management System!" << endl;

    do {
        cout << "\nMain Menu:" << endl;
        cout << "1. Add New Book" << endl;
        cout << "2. Search Book by Number" << endl;
        cout << "3. Remove Book" << endl;
        cout << "4. Change Book Details" << endl;
        cout << "5. Add New Customer" << endl;
        cout << "6. Update Customer Information" << endl;
        cout << "7. Remove Customer" << endl;
        cout << "8. Check Out Book" << endl;
        cout << "9. Return Book" << endl;
        cout << "10. Transaction Reports" << endl;
        cout << "0. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                bookManager.add_new_book();
                break;
            case 2:
                bookManager.search_book_by_number();
                break;
            case 3:
                bookManager.remove_book();
                break;
            case 4:
                bookManager.change_book_details();
                break;
            case 5:
                customerManager.new_customer();
                break;
            case 6:
                customerManager.update_customer_information();
                break;
            case 7:
                customerManager.remove_customers();
                break;
            case 8:
                transactionManager.Check_out();
                break;
            case 9:
                transactionManager.return_books();
                break;
            case 10:
                transactionManager.transaction_reports();
                break;
            case 0:
                cout << "Exiting program. Goodbye!" << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
                break;
        }
    } while (choice != 0);

    return 0;
}

