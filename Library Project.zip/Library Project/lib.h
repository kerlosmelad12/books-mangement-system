#include<iostream>
#include<string>
#include<fstream>
#include <sstream>

using namespace std;
class customer_Management {
public:
    void new_customer();
    void update_customer_information();
    void remove_customers();
};
class Book_Management{
	private:
		int total_books;
	public:
	  void add_new_book();
    void search_book_by_number();
    void remove_book();
    void change_book_details();
    
     Book_Management() : total_books(0) {} // Constructor to initialize total_books
};
class Transaction_Management {
public:
	void findOverduePayment();
    void return_books();
    void transaction_reports();
    void Check_out();
};
