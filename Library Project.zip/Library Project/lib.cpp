#include<iostream>
#include<string>
#include<fstream>
#include<vector>
#include"lib.h"
using namespace std;
void Book_Management::remove_book() {
    int searchID;
    cout << "Enter the book number to remove: ";
    cin >> searchID;

    ifstream inFile("book.txt");
    if (!inFile.is_open()) {
        cout << "Error opening file." << endl;
        return;
    }

    string line;
    bool found = false;

    ofstream tempFile("temp.txt");
    if (!tempFile.is_open()) {
        cout << "Error opening temp file." << endl;
        inFile.close();
        return;
    }

    while (getline(inFile, line)) {
        stringstream ss(line);
        int id;
        ss >> id;

        if (id == searchID) {
            found = true;
            cout << "Book removed:" << endl;
            cout << line << endl;
        } else {
            tempFile << line << endl;
        }
    }

    inFile.close();
    tempFile.close();

    if (!found) {
        cout << "Book with number " << searchID << " not found." << endl;
        remove("temp.txt");
    } else {
        remove("book.txt");
        rename("temp.txt", "book.txt");
        cout << "Book removed successfully." << endl;
    }
}
void Book_Management::search_book_by_number() {
    int searchID;
    cout << "Enter the book number to search: ";
    cin >> searchID;

    ifstream inFile("book.txt");
    if (!inFile.is_open()) {
        cout << "Error opening file." << endl;
        return;
    }

    string line;
    bool found = false;

    while (getline(inFile, line)) {
        stringstream ss(line);
        int id;
        ss >> id;

        if (id == searchID) {
            found = true;
            cout << "Book found:" << endl;
            cout << line << endl;
            break;
        }
    }

    inFile.close();

    if (!found) {
        cout << "Book with number " << searchID << " not found." << endl;
    }
}
void Book_Management::add_new_book() {
    ifstream inFile("book.txt");
    if (!inFile.is_open()) {
        cout << "Error opening file." << endl;
        return;
    }

    // Count the existing books in the file
    string line;
    while (getline(inFile, line)) {
        if (!line.empty()) {
            total_books++;
        }
    }
    inFile.close();

    int numBooksToAdd;
    cout << "Enter the number of books you want to add: ";
    cin >> numBooksToAdd;

    ofstream outFile("book.txt", ios::app);
    if (!outFile.is_open()) {
        cout << "Error opening file." << endl;
        return;
    }

    for (int i = 0; i < numBooksToAdd; ++i) {
        string title, author, genre, status;

        cout << "Enter book title: ";
        cin.ignore();
        getline(cin, title);

        cout << "Enter author: ";
        getline(cin, author);

        cout << "Enter genre: ";
        getline(cin, genre);

        cout << "Enter status: ";
        getline(cin, status);

        int newID = total_books + 1; // Increment the ID for the new book

        outFile << newID << ". \"" << title << "\" by " << author << " - " << genre << " - " << status << endl;

        total_books++; // Increment the total number of books

        cout << "Book added successfully." << endl;
    }

    outFile.close();

    cout << "Total number of books: " << total_books << endl;
}
void Book_Management::change_book_details() {
    int searchID;
    cout << "Enter the book number to change details: ";
    cin >> searchID;

    ifstream inFile("book.txt");
    if (!inFile.is_open()) {
        cout << "Error opening file." << endl;
        return;
    }

    string line;
    bool found = false;
    string currentInfo;
    string title, author, genre, status;

    while (getline(inFile, line)) {
        stringstream ss(line);
        int id;
        ss >> id;

        if (id == searchID) {
            found = true;
            currentInfo = line;

            // Extract book details from currentInfo
            size_t start = currentInfo.find("\"") + 1;
            size_t end = currentInfo.find("\"", start);
            title = currentInfo.substr(start, end - start);

            start = currentInfo.find("by ") + 3;
            end = currentInfo.find(" - ", start);
            author = currentInfo.substr(start, end - start);

            start = end + 3;
            end = currentInfo.find(" - ", start);
            genre = currentInfo.substr(start, end - start);

            start = end + 3;
            status = currentInfo.substr(start);

            // Display current book information
            cout << "Current Book Information:" << endl;
            cout << "1. Title: " << title << endl;
            cout << "2. Author: " << author << endl;
            cout << "3. Genre: " << genre << endl;
            cout << "4. Status: " << status << endl;

            // Prompt user for choice
            int choice;
            cout << "Enter the number of the detail you want to change (1-4): ";
            cin >> choice;

            // Prompt user for new detail
            string newDetail;
            cout << "Enter new detail: ";
            cin.ignore(); // Consume newline character
            getline(cin, newDetail);

            // Update chosen detail
            switch (choice) {
                case 1:
                    title = newDetail;
                    break;
                case 2:
                    author = newDetail;
                    break;
                case 3:
                    genre = newDetail;
                    break;
                case 4:
                    status = newDetail;
                    break;
                default:
                    cout << "Invalid choice. No detail changed." << endl;
                    break;
            }

            // Write modified book information to temp file
            ofstream tempFile("temp.txt", ios::app);
            if (!tempFile.is_open()) {
                cout << "Error opening temp file." << endl;
                inFile.close();
                return;
            }

            tempFile << id << ". \"" << title << "\" by " << author << " - " << genre << " - " << status << endl;
            tempFile.close();
        } else {
            // Write unchanged line to temp file
            ofstream tempFile("temp.txt", ios::app);
            if (!tempFile.is_open()) {
                cout << "Error opening temp file." << endl;
                inFile.close();
                return;
            }
            tempFile << line << endl;
            tempFile.close();
        }
    }

    inFile.close();

    if (!found) {
        cout << "Book with number " << searchID << " not found." << endl;
        remove("temp.txt");
    } else {
        remove("book.txt");
        rename("temp.txt", "book.txt");
        cout << "Book details changed successfully." << endl;
    }
}


void customer_Management::new_customer() {
    int numCustomers;
    cout << "Enter the number of new customers: ";
    cin >> numCustomers;

    ifstream lastIDFile("customer.txt");
    int lastID = 0;
    string line;

    while (getline(lastIDFile, line)) {
        if (!line.empty()) {
            stringstream ss(line);
            ss >> lastID;
        }
    }
    lastIDFile.close();

    for (int i = 0; i < numCustomers; ++i) {
        string fName, lName, Email, Membership;
        int Age;

        cout << "Please Enter Your first name: ";
        cin >> fName;
        cout << "Enter Your last name: ";
        cin >> lName;
        cout << "Email: ";
        cin >> Email;
        cout << "Membership: ";
        cin >> Membership;
        cout << "Age: ";
        cin >> Age;
        
        lastID++;

        ofstream outFile("customer.txt", ios::app);

        if (!outFile.is_open()) {
            cout << "Error opening file." << endl;
            return;
        }
        outFile << lastID << ". " << "Name: " << fName << " " << lName << ", "
                << "Email: " << Email << ", " << "Membership: " << Membership << ", " << "Age: " << Age << endl;

        outFile.close();

        cout << "New customer added successfully." << endl;
        cout << "The Total Of customers is : " << lastID << endl ;
        cout << "                     THANK YOU FOR GOINING HAVE A NICE DAY (;" <<endl;
    }
}
void customer_Management::remove_customers() {
    int searchID;
    cout << "Enter the ID of the customer: ";
    cin >> searchID;

    ifstream inFile("customer.txt");
    ofstream tempFile("temp.txt");

    if (!inFile.is_open() || !tempFile.is_open()) {
        cout << "Error opening file." << endl;
        return;
    }

    string line;
    bool found = false;

    while (getline(inFile, line)) {
        stringstream ss(line);
        int id;
        ss >> id;

        if (id == searchID) {
            found = true;

            string fName, lName, Email, Membership;
            int Age;

            ss.ignore(1000, ':');
            ss >> fName >> lName;

            ss.ignore(1000, ':');
            ss >> Email;

            ss.ignore(1000, ':');
            ss >> Membership;

            ss.ignore(1000, ':');
            ss >> Age;

            cout << "Current Information:" << endl;
            cout << "Name: " << fName << " " << lName << endl;
            cout << "Email: " << Email << endl;
            cout << "Membership: " << Membership << endl;
            cout << "Age: " << Age << endl;

            cout << "Select action for membership status:" << endl;
            cout << "1. Activate Membership" << endl;
            cout << "2. Deactivate Membership" << endl;
            int choice;
            cout << "Enter choice: ";
            cin >> choice;

            if (choice == 1) {
                Membership = "Active";
                cout << "Membership activated successfully." << endl;
            } else if (choice == 2) {
                Membership = "Inactive";
                cout << "Membership deactivated successfully." << endl;
            } else {
                cout << "Invalid choice. Membership status remains unchanged." << endl;
            }

            tempFile << id << ". " << "Name: " << fName << " " << lName << ", "
                    << "Email: " << Email << ", " << "Membership: " << Membership << ", " << "Age: " << Age << endl;
        } else {
            tempFile << line << endl;
        }
    }

    inFile.close();
    tempFile.close();

    if (!found) {
        cout << "Customer with ID " << searchID << " not found." << endl;
        remove("temp.txt");
    } else {
        remove("customer.txt");
        rename("temp.txt", "customer.txt");
    }
}
void customer_Management::update_customer_information() {
    int searchID;
    cout << "Enter the ID of the customer to modify: ";
    cin >> searchID;

    ifstream inFile("customer.txt");
    ofstream tempFile("temp.txt");

    if (!inFile.is_open() || !tempFile.is_open()) {
        cout << "Error opening file." << endl;
        return;
    }

    string line;
    bool found = false;

    while (getline(inFile, line)) {
        stringstream ss(line);
        int id;
        ss >> id;

        if (id == searchID) {
            found = true;

            // Extract current customer information
            string fName, lName, Email, Membership;
            int Age;

            ss.ignore(1000, ':'); // Ignore "Name: " text
            ss >> fName >> lName;

            ss.ignore(1000, ':'); // Ignore "Email: " text
            ss >> Email;

            ss.ignore(1000, ':'); // Ignore "Membership: " text
            ss >> Membership;

            ss.ignore(1000, ':'); // Ignore "Age: " text
            ss >> Age;

            // Display current information
            cout << "Current Information:" << endl;
            cout << "1. Name: " << fName << " " << lName << endl;
            cout << "2. Email: " << Email << endl;
            cout << "3. Membership: " << Membership << endl;
            cout << "4. Age: " << Age << endl;

            // Menu for modification
            cout << "Select which information to modify (1-4), 0 to skip: ";
            int choice;
            cin >> choice;

            switch (choice) {
                case 1:
                    cout << "Modify first name: ";
                    cin >> fName;
                    cout << "Modify last name: ";
                    cin >> lName;
                    break;
                case 2:
                    cout << "Modify Email: ";
                    cin >> Email;
                    break;
                case 3:
                    cout << "Modify Membership: ";
                    cin >> Membership;
                    break;
                case 4:
                    cout << "Modify Age: ";
                    cin >> Age;
                    break;
                default:
                    cout << "Skipping modification." << endl;
                    break;
            }

            // Write modified customer information to temp file
            tempFile << id << ". " << "Name: " << fName << " " << lName << ", "
                    << "Email: " << Email << ", " << "Membership: " << Membership << ", " << "Age: " << Age << endl;
        } else {
            tempFile << line << endl;
        }
    }

    inFile.close();
    tempFile.close();

    if (!found) {
        cout << "Customer with ID " << searchID << " not found." << endl;
        remove("temp.txt");
    } else {
        remove("customer.txt");
        rename("temp.txt", "customer.txt");
        cout << "Customer information modified successfully." << endl;
    }
}

void Transaction_Management::return_books(){
	cout<<"please,return book after you use it "<<endl;
}
void Transaction_Management::transaction_reports(){
	cout<<"please,keep quiet at the libaray "<<endl;
	cout<<"please,return book after you use it "<<endl;
	cout<<"please,save your book "<<endl;
}
void Transaction_Management::Check_out(){
string find_contact;
string titel;
fstream output;
output.open("book.txt",ios::in);
cout<<"who you want to find by titel? ";
cin>>find_contact;
if(output.is_open()){
	string title, author, genre,  availability;
	while(!output.eof()){
		output>>title>>author>>genre>>availability;
		if(titel==find_contact){
			cout<<"their data "<<author<<genre<<availability<<endl;

			}
			else{
				cout<<"not found that data ";
			}
			break;
		}
	}
	
}
